import { useState } from "react";
import { Settings } from "../lib/db";
import { Button } from "../components/ui/button";
import { exportJSON, importJSON } from "../lib/db";
import { Save, Download, Upload, Plus, Trash2 } from "lucide-react";

interface Props {
  settings: Settings;
  onUpdate: (fn: (s: Settings) => void) => void;
}

export function SettingsPage({ settings, onUpdate }: Props) {
  const [importErr, setImportErr] = useState<string | null>(null);
  const [importOk, setImportOk] = useState(false);

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const err = importJSON(ev.target?.result as string);
      if (err) { setImportErr(err); setImportOk(false); }
      else { setImportErr(null); setImportOk(true); setTimeout(() => setImportOk(false), 3000); }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-12">
      <div>
        <h2 className="text-xl font-bold mb-1">Settings</h2>
        <p className="text-sm text-muted-foreground">Manage branch settings, credit tiers, and strip inventory</p>
      </div>

      {/* Branch */}
      <Section title="Branch Info">
        <Label>Branch Name</Label>
        <input
          type="text"
          value={settings.branchName || "Fazal Din's Pharma Plus"}
          onChange={(e) => onUpdate((s) => { s.branchName = e.target.value; })}
          className="border border-border rounded-md px-3 py-2 text-sm w-full bg-white focus:outline-none focus:ring-2 focus:ring-ring"
          data-testid="setting-branch-name"
        />
        <Label className="mt-3">Final Closing every N shifts</Label>
        <input
          type="number"
          min={1}
          max={20}
          value={settings.finalEveryN}
          onChange={(e) => onUpdate((s) => { s.finalEveryN = parseInt(e.target.value) || 3; })}
          className="border border-border rounded-md px-3 py-2 text-sm w-32 bg-white focus:outline-none focus:ring-2 focus:ring-ring"
          data-testid="setting-final-every-n"
        />
      </Section>

      {/* Named Credits */}
      <Section title="Named Credit Accounts">
        <p className="text-xs text-muted-foreground mb-2">These accounts appear on every shift sheet</p>
        {settings.namedCredits.map((nc, i) => (
          <div key={i} className="flex items-center gap-2 mb-2">
            <input
              type="text"
              value={nc.label}
              onChange={(e) => onUpdate((s) => { s.namedCredits[i].label = e.target.value; })}
              className="border border-border rounded-md px-2 py-1.5 text-sm flex-1 bg-white focus:outline-none focus:ring-2 focus:ring-ring"
              data-testid={`setting-named-credit-${i}`}
            />
            <button
              onClick={() => onUpdate((s) => { s.namedCredits.splice(i, 1); })}
              className="p-1.5 text-muted-foreground hover:text-destructive transition-colors"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}
        <Button
          variant="ghost" size="sm"
          onClick={() => onUpdate((s) => { s.namedCredits.push({ label: "New Account" }); })}
          className="text-xs gap-1 text-primary px-0"
          data-testid="setting-add-named-credit"
        >
          <Plus size={12} /> Add Account
        </Button>
      </Section>

      {/* Sub Tiers */}
      <Section title="Staff Credit Tiers">
        <p className="text-xs text-muted-foreground mb-2">Each tier is a group of individual credit lines</p>
        {settings.subTiers.map((tier, ti) => (
          <div key={ti} className="mb-4 p-3 bg-muted/30 rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-2">
              <input
                type="text"
                value={tier.type}
                onChange={(e) => onUpdate((s) => { s.subTiers[ti].type = e.target.value; })}
                placeholder="Tier name"
                className="border border-border rounded-md px-2 py-1.5 text-sm flex-1 bg-white focus:outline-none focus:ring-2 focus:ring-ring font-semibold"
                data-testid={`setting-tier-${ti}-name`}
              />
              <button
                onClick={() => onUpdate((s) => { s.subTiers.splice(ti, 1); })}
                className="p-1 text-muted-foreground hover:text-destructive transition-colors"
              >
                <Trash2 size={14} />
              </button>
            </div>
            {tier.names.map((name, ni) => (
              <div key={ni} className="flex items-center gap-2 mb-1.5">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => onUpdate((s) => { s.subTiers[ti].names[ni] = e.target.value; })}
                  className="border border-border rounded-md px-2 py-1.5 text-sm flex-1 bg-white focus:outline-none focus:ring-2 focus:ring-ring"
                  data-testid={`setting-tier-${ti}-name-${ni}`}
                />
                <button
                  onClick={() => onUpdate((s) => { s.subTiers[ti].names.splice(ni, 1); })}
                  className="p-1 text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
            <Button
              variant="ghost" size="sm"
              onClick={() => onUpdate((s) => { s.subTiers[ti].names.push("New Name"); })}
              className="text-xs gap-1 text-primary px-0 mt-1"
            >
              <Plus size={12} /> Add Name
            </Button>
          </div>
        ))}
        <Button
          variant="ghost" size="sm"
          onClick={() => onUpdate((s) => { s.subTiers.push({ type: "New Tier", names: ["Name 1"] }); })}
          className="text-xs gap-1 text-primary px-0"
          data-testid="setting-add-tier"
        >
          <Plus size={12} /> Add Tier
        </Button>
      </Section>

      {/* Strips */}
      <Section title="Strip & Item Inventory">
        <p className="text-xs text-muted-foreground mb-2">Pre-configured items shown on every shift sheet</p>
        {settings.strips.map((strip, i) => (
          <div key={i} className="flex items-center gap-2 mb-2">
            <input
              type="text"
              value={strip.name}
              onChange={(e) => onUpdate((s) => { s.strips[i].name = e.target.value; })}
              className="border border-border rounded-md px-2 py-1.5 text-sm flex-1 bg-white focus:outline-none focus:ring-2 focus:ring-ring"
              data-testid={`setting-strip-name-${i}`}
            />
            <input
              type="number"
              value={strip.price}
              onChange={(e) => onUpdate((s) => { s.strips[i].price = parseFloat(e.target.value) || 0; })}
              className="border border-border rounded-md px-2 py-1.5 text-sm w-24 bg-white focus:outline-none focus:ring-2 focus:ring-ring text-right"
              placeholder="Price"
              data-testid={`setting-strip-price-${i}`}
            />
            <button
              onClick={() => onUpdate((s) => { s.strips.splice(i, 1); })}
              className="p-1.5 text-muted-foreground hover:text-destructive transition-colors"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}
        <Button
          variant="ghost" size="sm"
          onClick={() => onUpdate((s) => { s.strips.push({ name: "New Item", price: 0 }); })}
          className="text-xs gap-1 text-primary px-0"
          data-testid="setting-add-strip"
        >
          <Plus size={12} /> Add Item
        </Button>
      </Section>

      {/* Backup / Restore */}
      <Section title="Backup & Restore">
        <div className="flex flex-wrap gap-3">
          <Button
            variant="outline" size="sm" className="gap-2"
            onClick={exportJSON}
            data-testid="setting-export"
          >
            <Download size={14} /> Export Backup (JSON)
          </Button>
          <label className="cursor-pointer">
            <Button variant="outline" size="sm" className="gap-2 pointer-events-none" data-testid="setting-import">
              <Upload size={14} /> Import Backup
            </Button>
            <input type="file" accept=".json" className="sr-only" onChange={handleImport} />
          </label>
        </div>
        {importErr && <p className="text-xs text-destructive mt-2">{importErr}</p>}
        {importOk && <p className="text-xs text-green-600 mt-2">Backup imported successfully. Reload to see data.</p>}
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border p-4 bg-card shadow-sm space-y-2">
      <h3 className="font-bold text-sm mb-3 pb-2 border-b border-border">{title}</h3>
      {children}
    </div>
  );
}

function Label({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <p className={`text-xs text-muted-foreground font-semibold uppercase tracking-wide mb-1 ${className}`}>{children}</p>;
}
