import { useState, useEffect, useCallback, useRef } from "react";
import { SheetRecord, Shift, SHIFTS, fmtRs, srLabel, CASH_RESERVE } from "../lib/db";
import { Settings } from "../lib/db";
import { deriveAll, tillTotal, hsTotal, stripsTotal, miscTotal, creditTotal, depositTotal } from "../lib/calc";
import { SectionCard } from "../components/SectionCard";
import { NumberInput } from "../components/NumberInput";
import { DenomTable } from "../components/DenomTable";
import { MiscSection } from "../components/MiscSection";
import { CreditSection } from "../components/CreditSection";
import { StripsSection } from "../components/StripsSection";
import { GrandTotalRow } from "../components/GrandTotalRow";
import { OverrideInput } from "../components/OverrideInput";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Save, Share2, FileDown, CheckCircle2, ChevronDown, ChevronUp } from "lucide-react";
import { exportPDF, shareWhatsApp } from "../lib/pdf";

interface Props {
  date: string;
  shift: Shift;
  initialSheet: SheetRecord;
  settings: Settings;
  onSave: (data: SheetRecord) => void;
}

export function ShiftPage({ date, shift, initialSheet, settings, onSave }: Props) {
  const [sheet, setSheet] = useState<SheetRecord>(() => JSON.parse(JSON.stringify(initialSheet)));
  const [saved, setSaved] = useState(!initialSheet.draft);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    sales: true,
    returns: true,
    hs: true,
    strips: false,
    misc: false,
    cc: true,
    till: false,
    vault: false,
    credit: false,
    deposit: false,
    summary: true,
  });

  // Track latest save key to reset form when tab changes
  const prevKeyRef = useRef(`${date}_${shift}`);
  useEffect(() => {
    const key = `${date}_${shift}`;
    if (key !== prevKeyRef.current) {
      prevKeyRef.current = key;
      setSheet(JSON.parse(JSON.stringify(initialSheet)));
      setSaved(!initialSheet.draft);
    }
  }, [date, shift, initialSheet]);

  const patch = useCallback(<K extends keyof SheetRecord>(field: K, value: SheetRecord[K]) => {
    setSheet((s) => ({ ...s, [field]: value }));
    setSaved(false);
  }, []);

  const setOverride = (key: string, val: number) => {
    setSheet((s) => ({ ...s, overrides: { ...s.overrides, [key]: val } }));
    setSaved(false);
  };

  const clearOverride = (key: string) => {
    setSheet((s) => {
      const ov = { ...s.overrides };
      delete ov[key];
      return { ...s, overrides: ov };
    });
    setSaved(false);
  };

  const d = deriveAll(sheet, settings);

  const toggleSection = (k: string) =>
    setExpandedSections((s) => ({ ...s, [k]: !s[k] }));

  const handleSave = () => {
    const toSave: SheetRecord = {
      ...sheet,
      draft: false,
      outNetSale:   d.netSale,
      outCurrCC:    d.currCC,
      outShiftSale: d.shiftSale,
      outCust:      sheet.inLastBillNum,
      extraCash:    d.extraCash,
    };
    onSave(toSave);
    setSheet(toSave);
    setSaved(true);
  };

  const Sec = ({ id, title, accent, badge, children }: {
    id: string; title: string; accent?: "teal"|"blue"|"green"|"amber"|"red"|"purple";
    badge?: React.ReactNode; children: React.ReactNode;
  }) => (
    <div className="rounded-xl border border-border border-l-4 border-l-primary/60 shadow-sm overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-4 py-3 bg-card hover:bg-muted/30 transition-colors"
        onClick={() => toggleSection(id)}
        data-testid={`section-toggle-${id}`}
      >
        <div className="flex items-center gap-3">
          <span className="font-bold text-sm">{title}</span>
          {badge}
        </div>
        {expandedSections[id] ? <ChevronUp size={14} className="text-muted-foreground" /> : <ChevronDown size={14} className="text-muted-foreground" />}
      </button>
      {expandedSections[id] && (
        <div className="px-4 pb-4 pt-1 bg-card">
          {children}
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Shift header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="font-bold text-lg">{srLabel(shift)}</h2>
          <p className="text-sm text-muted-foreground">{date}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {saved && (
            <Badge variant="outline" className="gap-1 text-green-700 border-green-300 bg-green-50">
              <CheckCircle2 size={12} /> Saved
            </Badge>
          )}
          {!saved && (
            <Badge variant="outline" className="gap-1 text-amber-700 border-amber-300 bg-amber-50">
              Unsaved draft
            </Badge>
          )}
          <Button
            size="sm" variant="outline" className="gap-1"
            onClick={() => shareWhatsApp(date, shift, sheet, settings)}
            data-testid="btn-whatsapp"
          >
            <Share2 size={14} /> WhatsApp
          </Button>
          <Button
            size="sm" variant="outline" className="gap-1"
            onClick={() => exportPDF(date, shift, sheet, settings, settings.branchName || "Fazal Din's Pharma Plus")}
            data-testid="btn-pdf"
          >
            <FileDown size={14} /> PDF
          </Button>
          <Button
            size="sm" className="gap-1 bg-primary text-white hover:bg-primary/90"
            onClick={handleSave}
            data-testid="btn-save"
          >
            <Save size={14} /> Save Shift
          </Button>
        </div>
      </div>

      {/* ─── SALES ─── */}
      <Sec id="sales" title="Sales Data" badge={
        <span className="text-xs font-mono text-primary font-bold">{fmtRs(d.netSale)}</span>
      }>
        <div className="space-y-2">
          <Row label="System Cash (POS Sale)">
            <NumberInput value={sheet.inSysCash} onChange={(v) => patch("inSysCash", v)} highlight="blue" data-testid="in-sys-cash" />
          </Row>
          <Row label="Last Bill Amount">
            <NumberInput value={sheet.inLastBillAmt} onChange={(v) => patch("inLastBillAmt", v)} data-testid="in-last-bill-amt" />
          </Row>
          <Row label="Last Bill No.">
            <NumberInput value={sheet.inLastBillNum} onChange={(v) => patch("inLastBillNum", v)} step={1} data-testid="in-last-bill-num" />
          </Row>
          <Row label="Book 1 (Extra Sales)">
            <NumberInput value={sheet.inBook1} onChange={(v) => patch("inBook1", v)} data-testid="in-book1" />
          </Row>
          <Row label="Book 2 (Extra Sales)">
            <NumberInput value={sheet.inBook2} onChange={(v) => patch("inBook2", v)} data-testid="in-book2" />
          </Row>
          <hr className="border-border my-2" />
          <div className="text-xs text-muted-foreground">Customer Count Delta: {Math.max(0, sheet.inLastBillNum - (sheet.outCust || 0))} customers = Rs. {Math.max(0, sheet.inLastBillNum - (sheet.outCust || 0)).toLocaleString("en-PK")}</div>
          <OverrideInput
            label="Net Sale"
            computed={d.netSale}
            overrideVal={sheet.overrides?.netSale}
            fieldKey="netSale"
            onSet={setOverride}
            onClear={clearOverride}
            highlight="blue"
            data-testid="override-net-sale"
          />
          <OverrideInput
            label="Shift Sale"
            computed={d.shiftSale}
            overrideVal={sheet.overrides?.shiftSale}
            fieldKey="shiftSale"
            onSet={setOverride}
            onClear={clearOverride}
            data-testid="override-shift-sale"
          />
        </div>
      </Sec>

      {/* ─── RETURNS ─── */}
      <Sec id="returns" title="Returns" badge={
        <span className="text-xs font-mono text-red-600 font-bold">−{fmtRs(d.totalReturns)}</span>
      }>
        <div className="space-y-2">
          <Row label="POS Return 1"><NumberInput value={sheet.posRet1} onChange={(v) => patch("posRet1", v)} highlight="red" data-testid="pos-ret1" /></Row>
          <Row label="POS Return 2"><NumberInput value={sheet.posRet2} onChange={(v) => patch("posRet2", v)} highlight="red" data-testid="pos-ret2" /></Row>
          <Row label="POS Return 3"><NumberInput value={sheet.posRet3} onChange={(v) => patch("posRet3", v)} highlight="red" data-testid="pos-ret3" /></Row>
          <Row label="System Returns"><NumberInput value={sheet.posRetSys} onChange={(v) => patch("posRetSys", v)} highlight="red" data-testid="pos-ret-sys" /></Row>
          <div className="flex justify-between pt-1">
            <span className="text-sm font-semibold">Total Returns</span>
            <span className="font-mono text-sm font-bold text-red-600">{fmtRs(d.totalReturns)}</span>
          </div>
        </div>
      </Sec>

      {/* ─── HS ─── */}
      <Sec id="hs" title="HS Amount (A)" badge={
        <span className="text-xs font-mono text-green-700 font-bold">{fmtRs(d.A)}</span>
      }>
        <div className="space-y-2">
          {sheet.hsRows.map((row, i) => (
            <div key={i} className="flex items-center justify-between gap-2">
              <input
                type="text"
                value={row.lbl}
                onChange={(e) => {
                  const next = [...sheet.hsRows];
                  next[i] = { ...next[i], lbl: e.target.value };
                  patch("hsRows", next);
                }}
                className="border border-border rounded-md px-2 py-1.5 text-sm bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring flex-1"
                data-testid={`hs-label-${i}`}
              />
              <NumberInput
                value={row.val}
                onChange={(v) => {
                  const next = [...sheet.hsRows];
                  next[i] = { ...next[i], val: v };
                  patch("hsRows", next);
                }}
                highlight="green"
                data-testid={`hs-val-${i}`}
              />
            </div>
          ))}
          <Button
            variant="ghost" size="sm"
            onClick={() => patch("hsRows", [...sheet.hsRows, { lbl: "Additional", val: 0 }])}
            className="text-xs text-primary gap-1 px-0"
            data-testid="hs-add"
          >
            + Add HS Row
          </Button>
        </div>
      </Sec>

      {/* ─── STRIPS ─── */}
      <Sec id="strips" title="Strips & Items (B)" badge={
        <span className="text-xs font-mono text-green-700 font-bold">{fmtRs(d.B)}</span>
      }>
        <StripsSection
          strips={sheet.strips}
          auxStrips={sheet.auxStrips}
          onChange={(v) => patch("strips", v)}
          onAux={(v) => patch("auxStrips", v)}
          total={d.B}
        />
      </Sec>

      {/* ─── MISC ─── */}
      <Sec id="misc" title="Misc Charges (C)" badge={
        <span className="text-xs font-mono text-amber-700 font-bold">{fmtRs(d.C)}</span>
      }>
        <MiscSection rows={sheet.miscRows} onChange={(v) => patch("miscRows", v)} />
      </Sec>

      {/* ─── CC ─── */}
      <Sec id="cc" title="Credit Cards (D)" badge={
        <span className="text-xs font-mono text-purple-700 font-bold">{fmtRs(d.D)}</span>
      }>
        <div className="space-y-2">
          <div className="text-xs text-muted-foreground font-semibold uppercase tracking-wide mb-1">This Shift (Current CC)</div>
          <Row label="Company Sale"><NumberInput value={sheet.inCompSale} onChange={(v) => patch("inCompSale", v)} data-testid="cc-comp-sale" /></Row>
          <Row label="Alfalah CC"><NumberInput value={sheet.inAlfalah} onChange={(v) => patch("inAlfalah", v)} data-testid="cc-alfalah" /></Row>
          <Row label="Keenu / Digital"><NumberInput value={sheet.inKeenu} onChange={(v) => patch("inKeenu", v)} data-testid="cc-keenu" /></Row>
          <div className="flex justify-between">
            <span className="text-sm font-semibold">Current CC Total</span>
            <span className="font-mono text-sm font-bold">{fmtRs(d.currCC)}</span>
          </div>
          <hr className="border-border" />
          <div className="text-xs text-muted-foreground font-semibold uppercase tracking-wide mb-1">Carried Forward</div>
          <Row label="Previous CC (carried)">
            <span className="font-mono text-sm font-semibold text-purple-700">{fmtRs(d.prevCC)}</span>
          </Row>
          <hr className="border-border" />
          <div className="flex justify-between pt-1">
            <span className="text-sm font-bold">Total CC (D)</span>
            <span className="font-mono font-bold text-sm text-purple-700">{fmtRs(d.D)}</span>
          </div>
        </div>
      </Sec>

      {/* ─── TILL ─── */}
      <Sec id="till" title="Till / Cash in Hand (E)" badge={
        <span className="text-xs font-mono text-blue-700 font-bold">{fmtRs(d.E)}</span>
      }>
        <DenomTable
          label="Till Denomination"
          values={sheet.tillValues}
          onChange={(v) => patch("tillValues", v)}
          total={d.E}
          highlight="blue"
        />
      </Sec>

      {/* ─── VAULT ─── */}
      <Sec id="vault" title="Vault / Safe Drawer (F)" badge={
        <span className="text-xs font-mono text-blue-700 font-bold">{fmtRs(d.F)}</span>
      }>
        <DenomTable
          label="Vault Denomination"
          values={sheet.vaultValues}
          onChange={(v) => patch("vaultValues", v)}
          total={d.F}
          highlight="blue"
        />
      </Sec>

      {/* ─── CREDIT ─── */}
      <Sec id="credit" title="Credit Accounts (G)" badge={
        <span className="text-xs font-mono font-bold">{fmtRs(d.G)}</span>
      }>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm">Credit Adjustment</span>
            <NumberInput value={sheet.creditAdj} onChange={(v) => patch("creditAdj", v)} data-testid="credit-adj" />
          </div>
          <hr className="border-border" />
          <CreditSection
            namedCredits={sheet.namedCredits}
            tierCredits={sheet.tierCredits}
            auxCredits={sheet.auxCredits}
            settings={settings}
            onNamed={(v) => patch("namedCredits", v)}
            onTier={(v) => patch("tierCredits", v)}
            onAux={(v) => patch("auxCredits", v)}
            total={d.G}
          />
        </div>
      </Sec>

      {/* ─── DEPOSITS ─── */}
      <Sec id="deposit" title="Bank Deposits (H)" badge={
        <span className="text-xs font-mono font-bold">{fmtRs(d.H)}</span>
      }>
        <div className="space-y-2">
          {sheet.deposits.map((dep, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                type="text"
                value={dep.lbl}
                onChange={(e) => {
                  const next = [...sheet.deposits];
                  next[i] = { ...next[i], lbl: e.target.value };
                  patch("deposits", next);
                }}
                className="border border-border rounded-md px-2 py-1.5 text-sm bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring flex-1"
                data-testid={`deposit-label-${i}`}
              />
              <NumberInput
                value={dep.val}
                onChange={(v) => {
                  const next = [...sheet.deposits];
                  next[i] = { ...next[i], val: v };
                  patch("deposits", next);
                }}
                data-testid={`deposit-val-${i}`}
              />
            </div>
          ))}
          <Button
            variant="ghost" size="sm"
            onClick={() => patch("deposits", [...sheet.deposits, { lbl: "Deposit", val: 0 }])}
            className="text-xs text-primary gap-1 px-0"
            data-testid="deposit-add"
          >
            + Add Deposit
          </Button>
          <div className="flex justify-between pt-1 border-t border-border">
            <span className="text-sm font-bold">Total Deposits</span>
            <span className="font-mono font-bold text-sm">{fmtRs(d.H)}</span>
          </div>
        </div>
      </Sec>

      {/* ─── SUMMARY ─── */}
      <div id="print-area">
        <Sec id="summary" title="Shift Summary — Grand Total">
          <div className="space-y-0.5">
            <GrandTotalRow label="HS Amount" value={d.A} tag="A" />
            <GrandTotalRow label="Strips & Items" value={d.B} tag="B" />
            <GrandTotalRow label="Misc Charges" value={d.C} tag="C" />
            <GrandTotalRow label="Credit Cards (Curr + Prev)" value={d.D} tag="D" />
            <GrandTotalRow label="Till / Cash in Hand" value={d.E} tag="E" />
            <GrandTotalRow label="Vault / Safe" value={d.F} tag="F" />
            <GrandTotalRow label="Credit Accounts" value={d.G} tag="G" />
            <GrandTotalRow label="Bank Deposits" value={d.H} tag="H" />

            <div className="flex justify-between py-2 mt-2 bg-primary text-primary-foreground rounded-lg px-3">
              <span className="font-bold">Grand Total</span>
              <span className="font-mono font-bold">{fmtRs(d.grandTotal)}</span>
            </div>
            <div className="flex justify-between py-1.5 px-3 text-sm">
              <span className="text-muted-foreground">Less: Reserve Cash</span>
              <span className="font-mono text-red-600">−{fmtRs(CASH_RESERVE)}</span>
            </div>
            <div className="flex justify-between py-2 bg-green-50 border border-green-200 rounded-lg px-3">
              <span className="font-bold text-green-800">Net Liquid</span>
              <span className="font-mono font-bold text-green-800">{fmtRs(d.netLiquid)}</span>
            </div>

            <div className="pt-3 space-y-1.5 border-t border-border mt-3">
              <Row label="Net Sale (computed)">
                <span className="font-mono text-sm font-bold text-blue-700">{fmtRs(d.netSale)}</span>
              </Row>
              <Row label="Extra / Unaccounted Cash">
                <span className={`font-mono text-sm font-bold ${d.extraCash > 0 ? "text-green-700" : d.extraCash < 0 ? "text-red-600" : "text-foreground"}`}>
                  {fmtRs(d.extraCash)}
                </span>
              </Row>
            </div>
          </div>
        </Sec>
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2 py-0.5">
      <span className="text-sm flex-1">{label}</span>
      {children}
    </div>
  );
}
