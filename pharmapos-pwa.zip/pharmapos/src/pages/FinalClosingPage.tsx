import { Shift, aggregateSinceLastFinal, fmtRs, srLabel } from "../lib/db";
import { SectionCard } from "../components/SectionCard";
import { Badge } from "../components/ui/badge";
import { BarChart3, TrendingUp, Users, DollarSign } from "lucide-react";

interface Props {
  date: string;
  shift: Shift;
  refreshCount: number;
}

export function FinalClosingPage({ date, shift, refreshCount }: Props) {
  const agg = aggregateSinceLastFinal(date, shift);

  const statCard = (icon: React.ReactNode, label: string, value: string, color: string) => (
    <div className={`rounded-xl border p-4 ${color} flex items-center gap-3`}>
      <div className="p-2 bg-white/60 rounded-lg shrink-0">{icon}</div>
      <div>
        <p className="text-xs font-semibold opacity-70 uppercase tracking-wide">{label}</p>
        <p className="font-bold text-lg font-mono">{value}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="font-bold text-lg">Final Closing</h2>
          <p className="text-sm text-muted-foreground">
            {date} — Aggregates {agg.shiftCount} shift{agg.shiftCount !== 1 ? "s" : ""} since last final
          </p>
        </div>
        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-300 gap-1">
          <BarChart3 size={12} /> Final Closing
        </Badge>
      </div>

      {agg.shiftCount === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-muted-foreground">
          <p className="font-semibold mb-1">No saved shifts found</p>
          <p className="text-sm">Save individual shift closings first, then view the Final Closing summary here.</p>
        </div>
      ) : (
        <>
          {/* Stat cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {statCard(
              <Users size={18} className="text-blue-700" />,
              "Total Customers",
              agg.totalCustomers.toLocaleString("en-PK"),
              "bg-blue-50 border-blue-200 text-blue-800"
            )}
            {statCard(
              <DollarSign size={18} className="text-green-700" />,
              "Total Shift Sale",
              fmtRs(agg.totalShiftSale),
              "bg-green-50 border-green-200 text-green-800"
            )}
            {statCard(
              <TrendingUp size={18} className="text-red-700" />,
              "Total Returns",
              fmtRs(agg.totalManualReturns),
              "bg-red-50 border-red-200 text-red-800"
            )}
            {statCard(
              <BarChart3 size={18} className="text-amber-700" />,
              "Extra Cash",
              fmtRs(agg.totalExtraCash),
              "bg-amber-50 border-amber-200 text-amber-800"
            )}
          </div>

          {/* Breakdown table */}
          <SectionCard title="Shifts Included" accent="purple">
            <div className="space-y-1 text-sm">
              {agg.labels.map((lbl, i) => (
                <div key={i} className="flex items-center gap-2 py-0.5">
                  <span className="w-3 h-3 rounded-full bg-primary/30 shrink-0" />
                  <span className="text-muted-foreground">{lbl}</span>
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Aggregate Summary" accent="green">
            <div className="space-y-2">
              <Row label="Shifts Counted" value={String(agg.shiftCount)} />
              <Row label="Total Customers" value={agg.totalCustomers.toLocaleString("en-PK")} />
              <Row label="Total Shift Sale" value={fmtRs(agg.totalShiftSale)} bold />
              <Row label="Total Returns" value={fmtRs(agg.totalManualReturns)} />
              <Row label="Net Sale (after returns)" value={fmtRs(agg.totalShiftSale - agg.totalManualReturns)} bold />
              <Row label="Total Extra Cash" value={fmtRs(agg.totalExtraCash)} />
            </div>
          </SectionCard>

          {agg.lastFinal && (
            <div className="text-xs text-muted-foreground text-center">
              Previous Final Closing: {agg.lastFinal.key.replace("_", " — ")}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex justify-between py-1 border-b border-border/50 ${bold ? "font-bold" : ""}`}>
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className="font-mono text-sm">{value}</span>
    </div>
  );
}
