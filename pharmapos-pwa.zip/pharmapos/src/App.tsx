import { useState } from "react";
import { SHIFTS, Shift } from "./lib/db";
import { useStore } from "./lib/useStore";
import { ShiftPage } from "./pages/ShiftPage";
import { FinalClosingPage } from "./pages/FinalClosingPage";
import { SettingsPage } from "./pages/SettingsPage";
import { Moon, Sun, Sunset, BarChart3, Settings as SettingsIcon, ChevronLeft, ChevronRight, Calendar, Building2 } from "lucide-react";

const SHIFT_ICONS: Record<Shift, React.ReactNode> = {
  Night:   <Moon size={14} />,
  Morning: <Sun size={14} />,
  Evening: <Sunset size={14} />,
};

type Tab = Shift | "final" | "settings";

function addDays(dateStr: string, n: number): string {
  const d = new Date(dateStr + "T12:00:00");
  d.setDate(d.getDate() + n);
  return d.toISOString().split("T")[0];
}

export default function App() {
  const store = useStore();
  const [activeTab, setActiveTab] = useState<Tab>("Night");

  const sheetForCurrentTab = (tab: Shift) => store.getSheet(store.date, tab);

  const handleSave = (shift: Shift) => (data: import("./lib/db").SheetRecord) => {
    store.saveSheet(store.date, shift, data);
  };

  const isToday = store.date === new Date().toISOString().split("T")[0];

  return (
    <div className="min-h-screen bg-background">
      {/* ── Top nav ── */}
      <header className="sticky top-0 z-50 bg-sidebar text-sidebar-foreground shadow-lg">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 size={20} className="text-primary shrink-0" />
            <div>
              <p className="font-bold text-sm leading-tight">{store.settings.branchName || "Fazal Din's Pharma Plus"}</p>
              <p className="text-[10px] text-sidebar-foreground/60">Shift Register</p>
            </div>
          </div>

          {/* Date picker */}
          <div className="flex items-center gap-1 bg-sidebar-accent rounded-lg px-2 py-1">
            <button
              onClick={() => store.setDate(addDays(store.date, -1))}
              className="p-1 hover:text-primary transition-colors"
              data-testid="date-prev"
            >
              <ChevronLeft size={14} />
            </button>
            <div className="flex items-center gap-1.5 px-1">
              <Calendar size={12} className="text-primary" />
              <input
                type="date"
                value={store.date}
                onChange={(e) => store.setDate(e.target.value)}
                className="bg-transparent text-xs font-semibold focus:outline-none text-sidebar-foreground cursor-pointer w-28"
                data-testid="date-picker"
              />
            </div>
            <button
              onClick={() => store.setDate(addDays(store.date, 1))}
              className="p-1 hover:text-primary transition-colors"
              data-testid="date-next"
            >
              <ChevronRight size={14} />
            </button>
            {!isToday && (
              <button
                onClick={() => store.setDate(new Date().toISOString().split("T")[0])}
                className="text-[10px] text-primary font-semibold ml-1 hover:underline"
                data-testid="date-today"
              >
                Today
              </button>
            )}
          </div>

          <button
            onClick={() => setActiveTab(activeTab === "settings" ? "Night" : "settings")}
            className={`p-2 rounded-lg transition-colors ${activeTab === "settings" ? "bg-primary text-primary-foreground" : "hover:bg-sidebar-accent"}`}
            data-testid="nav-settings"
          >
            <SettingsIcon size={16} />
          </button>
        </div>

        {/* ── Shift tabs ── */}
        <div className="max-w-3xl mx-auto px-4">
          <div className="flex gap-0.5 border-t border-sidebar-border">
            {SHIFTS.map((shift) => {
              const key = `${store.date}_${shift}`;
              const exists = !!store.sheets[key] && !store.sheets[key].draft;
              return (
                <button
                  key={shift}
                  onClick={() => setActiveTab(shift)}
                  className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold transition-all border-b-2 ${
                    activeTab === shift
                      ? "border-primary text-primary bg-primary/10"
                      : "border-transparent text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
                  }`}
                  data-testid={`tab-${shift.toLowerCase()}`}
                >
                  {SHIFT_ICONS[shift]}
                  {shift}
                  {exists && (
                    <span className="w-1.5 h-1.5 rounded-full bg-green-400 shrink-0" />
                  )}
                </button>
              );
            })}
            <button
              onClick={() => setActiveTab("final")}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold transition-all border-b-2 ml-auto ${
                activeTab === "final"
                  ? "border-purple-400 text-purple-300 bg-purple-500/10"
                  : "border-transparent text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
              }`}
              data-testid="tab-final"
            >
              <BarChart3 size={14} />
              Final
            </button>
          </div>
        </div>
      </header>

      {/* ── Content ── */}
      <main className="max-w-3xl mx-auto px-4 py-5">
        {activeTab === "settings" ? (
          <SettingsPage
            settings={store.settings}
            onUpdate={store.updateSettings}
          />
        ) : activeTab === "final" ? (
          <FinalClosingPage
            date={store.date}
            shift={store.activeShift}
            refreshCount={store.refreshCount}
          />
        ) : (
          <ShiftPage
            key={`${store.date}_${activeTab}`}
            date={store.date}
            shift={activeTab as Shift}
            initialSheet={sheetForCurrentTab(activeTab as Shift)}
            settings={store.settings}
            onSave={handleSave(activeTab as Shift)}
          />
        )}
      </main>
    </div>
  );
}
