import { ReactNode } from "react";

interface Props {
  title: string;
  subtitle?: string;
  badge?: ReactNode;
  children: ReactNode;
  className?: string;
  accent?: "teal" | "blue" | "green" | "amber" | "red" | "purple";
}

const ACCENT_COLORS = {
  teal:   "border-l-[hsl(174,72%,40%)] bg-[hsl(174,72%,98%)]",
  blue:   "border-l-blue-500 bg-blue-50/40",
  green:  "border-l-green-500 bg-green-50/40",
  amber:  "border-l-amber-500 bg-amber-50/40",
  red:    "border-l-red-500 bg-red-50/40",
  purple: "border-l-purple-500 bg-purple-50/40",
};

export function SectionCard({ title, subtitle, badge, children, className = "", accent = "teal" }: Props) {
  return (
    <div className={`rounded-xl border border-border border-l-4 ${ACCENT_COLORS[accent]} p-4 shadow-sm ${className}`}>
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-bold text-sm tracking-wide">{title}</h3>
          {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
        </div>
        {badge && <div className="shrink-0">{badge}</div>}
      </div>
      {children}
    </div>
  );
}
