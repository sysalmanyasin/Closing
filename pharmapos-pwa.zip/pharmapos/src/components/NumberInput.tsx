import { useRef, useState, useEffect } from "react";

interface Props {
  value: number;
  onChange: (v: number) => void;
  className?: string;
  readOnly?: boolean;
  placeholder?: string;
  "data-testid"?: string;
  step?: number;
  min?: number;
  highlight?: "blue" | "green" | "amber" | "red";
}

export function NumberInput({
  value,
  onChange,
  className = "",
  readOnly = false,
  placeholder = "0",
  step = 1,
  min,
  highlight,
  ...rest
}: Props) {
  const ref = useRef<HTMLInputElement>(null);
  const [local, setLocal] = useState(value === 0 ? "" : String(value));
  // Track whether we're actively editing — if so, don't sync from parent
  const editingRef = useRef(false);

  useEffect(() => {
    // Only sync from parent when not actively editing
    if (!editingRef.current) {
      setLocal(value === 0 ? "" : String(value));
    }
  }, [value]);

  const hlClass = highlight ? `highlight-${highlight}` : "";

  const commit = (raw: string) => {
    const n = parseFloat(raw);
    const v = isNaN(n) ? 0 : n;
    setLocal(v === 0 ? "" : String(v));
    onChange(v);
  };

  return (
    <input
      ref={ref}
      type="number"
      inputMode="numeric"
      step={step}
      min={min}
      readOnly={readOnly}
      placeholder={readOnly ? "" : placeholder}
      value={local}
      className={`row-input ${readOnly ? "computed" : ""} ${hlClass} ${className}`}
      onChange={(e) => {
        // Only update local display — do NOT call onChange yet
        // This prevents parent re-render on every keystroke
        setLocal(e.target.value);
      }}
      onFocus={() => {
        editingRef.current = true;
        if (!readOnly && (value === 0 || local === "0")) setLocal("");
      }}
      onBlur={() => {
        editingRef.current = false;
        commit(local);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          editingRef.current = false;
          commit(local);
          ref.current?.blur();
        }
      }}
      {...rest}
    />
  );
}
