import { useRef, useState, useEffect } from "react";

interface Props {
  value: number;
  onChange: (v: number) => void;
  className?: string;
  readOnly?: boolean;
  placeholder?: string;
  "data-testid"?: string;
  step?: number;
  min?: number;
  highlight?: "blue" | "green" | "amber" | "red";
}

export function NumberInput({
  value,
  onChange,
  className = "",
  readOnly = false,
  placeholder = "0",
  step = 1,
  min,
  highlight,
  ...rest
}: Props) {
  const ref = useRef<HTMLInputElement>(null);
  const [local, setLocal] = useState(value === 0 ? "" : String(value));

  useEffect(() => {
    if (document.activeElement !== ref.current) {
      setLocal(value === 0 ? "" : String(value));
    }
  }, [value]);

  const hlClass = highlight
    ? `highlight-${highlight}`
    : "";

  return (
    <input
      ref={ref}
      type="number"
      inputMode="decimal"
      step={step}
      min={min}
      readOnly={readOnly}
      placeholder={readOnly ? "" : placeholder}
      value={local}
      className={`row-input ${readOnly ? "computed" : ""} ${hlClass} ${className}`}
      onChange={(e) => {
        setLocal(e.target.value);
        const n = parseFloat(e.target.value);
        onChange(isNaN(n) ? 0 : n);
      }}
      onFocus={() => {
        if (!readOnly && (value === 0 || local === "0")) setLocal("");
      }}
      onBlur={() => {
        const n = parseFloat(local);
        const v = isNaN(n) ? 0 : n;
        setLocal(v === 0 ? "" : String(v));
        onChange(v);
      }}
      {...rest}
    />
  );
}
