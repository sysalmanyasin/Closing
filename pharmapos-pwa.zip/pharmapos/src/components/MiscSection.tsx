import { MiscRow } from "../lib/db";
import { NumberInput } from "./NumberInput";
import { Button } from "./ui/button";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  rows: MiscRow[];
  onChange: (rows: MiscRow[]) => void;
}

const STATUS_COLORS: Record<string, string> = {
  Active:    "bg-green-50 text-green-700 border-green-300",
  Confirmed: "bg-amber-50 text-amber-700 border-amber-300",
  Cleared:   "bg-gray-100 text-gray-400 border-gray-200",
};

export function MiscSection({ rows, onChange }: Props) {
  const setRow = (i: number, patch: Partial<MiscRow>) => {
    const next = [...rows];
    next[i] = { ...next[i], ...patch };
    onChange(next);
  };

  const addRow = () => {
    onChange([...rows, { label: "", val: 0, status: "Active" }]);
  };

  const removeRow = (i: number) => {
    onChange(rows.filter((_, idx) => idx !== i));
  };

  const total = rows.filter((r) => r.status === "Active").reduce((s, r) => s + (r.val || 0), 0);

  return (
    <div className="space-y-2">
      {rows.map((row, i) => (
        <div key={i} className="flex items-center gap-2">
          <input
            type="text"
            value={row.label}
            disabled={row.status === "Cleared"}
            placeholder={`Misc ${i + 1}`}
            onChange={(e) => setRow(i, { label: e.target.value })}
            className="border border-border rounded-md px-2 py-1.5 text-sm bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring flex-1 min-w-0"
            data-testid={`misc-label-${i}`}
          />
          <NumberInput
            value={row.val}
            onChange={(v) => setRow(i, { val: v })}
            readOnly={row.status !== "Active"}
            data-testid={`misc-val-${i}`}
          />
          <select
            value={row.status}
            onChange={(e) => setRow(i, { status: e.target.value as MiscRow["status"] })}
            className={`text-xs font-semibold rounded border px-1 py-1.5 focus:outline-none focus:ring-2 focus:ring-ring ${STATUS_COLORS[row.status]}`}
            data-testid={`misc-status-${i}`}
          >
            <option value="Active">Active</option>
            <option value="Confirmed">Confirmed</option>
            <option value="Cleared">Cleared</option>
          </select>
          <button
            onClick={() => removeRow(i)}
            className="p-1 text-muted-foreground hover:text-destructive transition-colors"
            data-testid={`misc-remove-${i}`}
          >
            <Trash2 size={14} />
          </button>
        </div>
      ))}
      <div className="flex items-center justify-between pt-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={addRow}
          className="text-xs gap-1 text-primary"
          data-testid="misc-add"
        >
          <Plus size={12} /> Add Misc Row
        </Button>
        <span className="text-sm font-bold font-mono text-amber-700">
          Total: Rs. {Math.round(total).toLocaleString("en-PK")}
        </span>
      </div>
    </div>
  );
}
