import { fmtRs } from "../lib/db";

interface GrandTotalProps {
  label: string;
  value: number;
  tag: string;
  className?: string;
}

export function GrandTotalRow({ label, value, tag, className = "" }: GrandTotalProps) {
  return (
    <div className={`flex items-center justify-between py-1.5 border-b border-border/60 ${className}`}>
      <div className="flex items-center gap-2">
        <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center shrink-0">
          {tag}
        </span>
        <span className="text-sm">{label}</span>
      </div>
      <span className="font-mono font-semibold text-sm">{fmtRs(value)}</span>
    </div>
  );
}
