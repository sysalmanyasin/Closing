import { useState } from "react";
import { fmtRs } from "../lib/db";
import { Pencil, RotateCcw } from "lucide-react";
import { NumberInput } from "./NumberInput";

interface Props {
  label: string;
  computed: number;
  overrideVal: number | undefined;
  fieldKey: string;
  onSet: (key: string, val: number) => void;
  onClear: (key: string) => void;
  highlight?: "blue" | "green" | "amber" | "red";
  "data-testid"?: string;
}

export function OverrideInput({ label, computed, overrideVal, fieldKey, onSet, onClear, highlight, ...rest }: Props) {
  const [editing, setEditing] = useState(false);
  const hasOverride = overrideVal !== undefined;

  return (
    <div className="flex items-center justify-between gap-2 py-1">
      <span className="text-sm flex-1">{label}</span>
      {editing ? (
        <div className="flex items-center gap-1">
          <NumberInput
            value={hasOverride ? overrideVal! : computed}
            onChange={(v) => onSet(fieldKey, v)}
            highlight={highlight}
            {...rest}
          />
          <button
            onClick={() => {
              if (hasOverride) onClear(fieldKey);
              setEditing(false);
            }}
            className="p-1 text-muted-foreground hover:text-primary transition-colors"
            title="Reset to computed"
          >
            <RotateCcw size={13} />
          </button>
          <button
            onClick={() => setEditing(false)}
            className="p-1 text-primary hover:text-primary/80 transition-colors text-xs font-semibold"
          >
            ✓
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-1">
          <span className={`font-mono text-sm font-semibold ${hasOverride ? "text-amber-700 underline decoration-dotted" : ""}`}>
            {fmtRs(hasOverride ? overrideVal! : computed)}
            {hasOverride && <span className="ml-1 text-[10px] opacity-70">(override)</span>}
          </span>
          <button
            onClick={() => setEditing(true)}
            className="p-1 text-muted-foreground hover:text-primary transition-colors"
            title="Override value"
          >
            <Pencil size={11} />
          </button>
        </div>
      )}
    </div>
  );
}
