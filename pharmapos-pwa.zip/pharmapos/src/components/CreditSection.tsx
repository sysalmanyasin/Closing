import { CreditRow, TierCredit, Settings } from "../lib/db";
import { NumberInput } from "./NumberInput";
import { Button } from "./ui/button";
import { Plus, Trash2 } from "lucide-react";
import { fmtRs } from "../lib/db";

interface Props {
  namedCredits: CreditRow[];
  tierCredits: TierCredit[];
  auxCredits: CreditRow[];
  settings: Settings;
  onNamed: (rows: CreditRow[]) => void;
  onTier: (rows: TierCredit[]) => void;
  onAux: (rows: CreditRow[]) => void;
  total: number;
}

export function CreditSection({
  namedCredits, tierCredits, auxCredits, settings,
  onNamed, onTier, onAux, total
}: Props) {
  const setNamed = (i: number, val: number) => {
    const next = [...namedCredits];
    next[i] = { ...next[i], val };
    onNamed(next);
  };

  const setTier = (i: number, val: number) => {
    const next = [...tierCredits];
    next[i] = { ...next[i], val };
    onTier(next);
  };

  const setAux = (i: number, patch: Partial<CreditRow>) => {
    const next = [...auxCredits];
    next[i] = { ...next[i], ...patch };
    onAux(next);
  };

  const addAux = () => {
    onAux([...auxCredits, { lbl: "", val: 0 }]);
  };

  const removeAux = (i: number) => {
    onAux(auxCredits.filter((_, idx) => idx !== i));
  };

  // Group tier credits by type
  const tierGroups = (settings.subTiers ?? []).map((tier) => ({
    type: tier.type,
    items: tierCredits.filter((tc) => tc.tIdx === tier.type),
    baseIdx: tierCredits.findIndex((tc) => tc.tIdx === tier.type),
  }));

  return (
    <div className="space-y-4">
      {/* Named credits */}
      {namedCredits.length > 0 && (
        <div className="space-y-2">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Named Accounts</div>
          {namedCredits.map((c, i) => (
            <div key={i} className="flex items-center justify-between gap-2">
              <span className="text-sm flex-1">{c.lbl}</span>
              <NumberInput
                value={c.val}
                onChange={(v) => setNamed(i, v)}
                data-testid={`credit-named-${i}`}
              />
            </div>
          ))}
        </div>
      )}

      {/* Tier credits */}
      {tierGroups.map((group) => (
        <div key={group.type} className="space-y-2">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{group.type}</div>
          {group.items.map((item, localIdx) => {
            const globalIdx = group.baseIdx + localIdx;
            return (
              <div key={item.name} className="flex items-center justify-between gap-2">
                <span className="text-sm flex-1">{item.name}</span>
                <NumberInput
                  value={item.val}
                  onChange={(v) => setTier(globalIdx, v)}
                  data-testid={`credit-tier-${globalIdx}`}
                />
              </div>
            );
          })}
        </div>
      ))}

      {/* Aux credits */}
      {auxCredits.length > 0 && (
        <div className="space-y-2">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Additional Credit</div>
          {auxCredits.map((c, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                type="text"
                value={c.lbl}
                placeholder="Label"
                onChange={(e) => setAux(i, { lbl: e.target.value })}
                className="border border-border rounded-md px-2 py-1.5 text-sm bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring flex-1"
                data-testid={`credit-aux-label-${i}`}
              />
              <NumberInput
                value={c.val}
                onChange={(v) => setAux(i, { val: v })}
                data-testid={`credit-aux-val-${i}`}
              />
              <button
                onClick={() => removeAux(i)}
                className="p-1 text-muted-foreground hover:text-destructive transition-colors"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between pt-2 border-t border-border">
        <Button variant="ghost" size="sm" onClick={addAux} className="text-xs gap-1 text-primary">
          <Plus size={12} /> Add Credit Row
        </Button>
        <span className="text-sm font-bold font-mono">{fmtRs(total)}</span>
      </div>
    </div>
  );
}
