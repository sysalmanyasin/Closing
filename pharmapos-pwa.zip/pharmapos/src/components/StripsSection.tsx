import { StripRow } from "../lib/db";
import { NumberInput } from "./NumberInput";
import { Button } from "./ui/button";
import { Plus, Trash2 } from "lucide-react";
import { fmtRs } from "../lib/db";

interface Props {
  strips: StripRow[];
  auxStrips: StripRow[];
  onChange: (strips: StripRow[]) => void;
  onAux: (strips: StripRow[]) => void;
  total: number;
}

export function StripsSection({ strips, auxStrips, onChange, onAux, total }: Props) {
  const setStrip = (i: number, qty: number) => {
    const next = [...strips];
    next[i] = { ...next[i], qty };
    onChange(next);
  };

  const setAux = (i: number, patch: Partial<StripRow>) => {
    const next = [...auxStrips];
    next[i] = { ...next[i], ...patch };
    onAux(next);
  };

  const addAux = () => {
    onAux([...auxStrips, { lbl: "", price: 0, qty: 0 }]);
  };

  const removeAux = (i: number) => {
    onAux(auxStrips.filter((_, idx) => idx !== i));
  };

  return (
    <div className="space-y-2">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Strip Inventory</div>
      {strips.map((s, i) => (
        <div key={i} className="flex items-center justify-between gap-2">
          <span className="text-sm flex-1 truncate">{s.lbl}</span>
          <span className="text-xs text-muted-foreground w-16 text-right font-mono">×{fmtRs(s.price)}</span>
          <NumberInput
            value={s.qty}
            onChange={(v) => setStrip(i, v)}
            step={1}
            min={0}
            placeholder="0"
            data-testid={`strip-qty-${i}`}
          />
          <span className="text-xs font-mono text-right w-24 text-muted-foreground">
            {fmtRs(s.qty * s.price)}
          </span>
        </div>
      ))}

      {/* Aux strips */}
      {auxStrips.length > 0 && (
        <div className="space-y-2 pt-2 border-t border-border">
          <div className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">Extra Items</div>
          {auxStrips.map((s, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                type="text"
                value={s.lbl}
                placeholder="Item name"
                onChange={(e) => setAux(i, { lbl: e.target.value })}
                className="border border-border rounded-md px-2 py-1.5 text-sm bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring flex-1 min-w-0"
                data-testid={`aux-strip-label-${i}`}
              />
              <input
                type="number"
                value={s.price || ""}
                placeholder="Price"
                onChange={(e) => setAux(i, { price: parseFloat(e.target.value) || 0 })}
                className="row-input w-24"
                data-testid={`aux-strip-price-${i}`}
              />
              <NumberInput
                value={s.qty}
                onChange={(v) => setAux(i, { qty: v })}
                data-testid={`aux-strip-qty-${i}`}
              />
              <button
                onClick={() => removeAux(i)}
                className="p-1 text-muted-foreground hover:text-destructive transition-colors"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between pt-2 border-t border-border">
        <Button variant="ghost" size="sm" onClick={addAux} className="text-xs gap-1 text-primary">
          <Plus size={12} /> Add Item
        </Button>
        <span className="text-sm font-bold font-mono">{fmtRs(total)}</span>
      </div>
    </div>
  );
}
