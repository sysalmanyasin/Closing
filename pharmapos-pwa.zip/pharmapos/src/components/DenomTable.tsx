import { DENOMS } from "../lib/db";
import { fmtRs } from "../lib/db";
import { NumberInput } from "./NumberInput";

interface Props {
  label: string;
  values: number[];
  onChange: (vals: number[]) => void;
  total: number;
  highlight?: "blue" | "green" | "amber" | "red";
}

export function DenomTable({ label, values, onChange, total, highlight }: Props) {
  return (
    <div className="space-y-1">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{label}</div>
      {DENOMS.map((d, i) => (
        <div key={d.label} className="flex items-center justify-between gap-2">
          <span className="text-xs text-muted-foreground w-36 shrink-0">{d.label}</span>
          <NumberInput
            value={values[i] || 0}
            onChange={(v) => {
              const next = [...values];
              next[i] = v;
              onChange(next);
            }}
            placeholder="0"
            step={1}
            min={0}
            data-testid={`denom-${label.toLowerCase().replace(/\s+/g, "-")}-${i}`}
          />
          <span className="text-xs font-mono text-right w-28 text-muted-foreground">
            {fmtRs((values[i] || 0) * d.mult)}
          </span>
        </div>
      ))}
      <div className="flex items-center justify-between pt-2 border-t border-border mt-2">
        <span className="text-sm font-bold">Total</span>
        <span className={`font-mono font-bold text-sm ${highlight === "blue" ? "text-blue-700" : highlight === "green" ? "text-green-700" : "text-foreground"}`}>
          {fmtRs(total)}
        </span>
      </div>
    </div>
  );
}
