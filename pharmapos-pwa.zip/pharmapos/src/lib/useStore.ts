/* ─── React state wrapper for PharmaPos DB ─── */
import { useState, useCallback, useEffect, useRef } from "react";
import {
  DB, getDB, updateDB, SheetRecord, Shift, SHIFTS, Settings,
  pullPreviousShift, timelineStep, aggregateSinceLastFinal
} from "./db";

function today() {
  return new Date().toISOString().split("T")[0];
}

function makeBlankSheet(settings: Settings, date: string, shift: Shift): SheetRecord {
  const namedCredits = (settings.namedCredits ?? []).map((c) => ({ lbl: c.label, val: 0 }));
  const tierCredits = (settings.subTiers ?? []).flatMap((tier) =>
    (tier.names ?? []).map((name) => ({ tIdx: tier.type, name, val: 0 }))
  );
  const strips = (settings.strips ?? []).map((s) => ({ lbl: s.name, price: s.price, qty: 0 }));
  return {
    profileMode: "shift",
    draft: true,
    overrides: {},
    inSysCash: 0,
    inLastBillAmt: 0,
    inLastBillNum: 0,
    inCompSale: 0,
    inAlfalah: 0,
    inKeenu: 0,
    inBook1: 0,
    inBook2: 0,
    posRet1: 0,
    posRet2: 0,
    posRet3: 0,
    posRetSys: 0,
    outNetSale: 0,
    outCurrCC: 0,
    outPrevCC: 0,
    outTotalE: 0,
    creditAdj: 0,
    extraCash: 0,
    outTotalF: 0,
    outTotalCash: 0,
    outShiftSale: 0,
    outCust: 0,
    finalSysReturns: 0,
    finalNetSale: 0,
    finalPrevSale: 0,
    hsRows: [
      { lbl: "HS Amount", val: 0 },
      { lbl: "Additional", val: 0 },
    ],
    strips,
    auxStrips: [],
    tillValues: Array(8).fill(0),
    vaultValues: Array(8).fill(0),
    namedCredits,
    tierCredits,
    auxCredits: [],
    deposits: [
      { lbl: "MCB Deposit", val: 0 },
      { lbl: "Meezan Deposit", val: 0 },
    ],
    miscRows: [
      { label: "Misc 1", val: 0, status: "Active" },
      { label: "Misc 2", val: 0, status: "Active" },
      { label: "Misc 3", val: 0, status: "Active" },
      { label: "Misc 4", val: 0, status: "Active" },
      { label: "Misc 5", val: 0, status: "Active" },
    ],
  };
}

export interface StoreAPI {
  date: string;
  setDate: (d: string) => void;
  activeShift: Shift;
  setActiveShift: (s: Shift) => void;
  sheets: Record<string, SheetRecord>;
  settings: Settings;
  saveSheet: (date: string, shift: Shift, data: SheetRecord) => void;
  getSheet: (date: string, shift: Shift) => SheetRecord;
  getSheetKey: (date: string, shift: Shift) => string;
  updateSettings: (fn: (s: Settings) => void) => void;
  triggerRefresh: () => void;
  refreshCount: number;
}

export function useStore(): StoreAPI {
  const [date, setDateRaw] = useState<string>(today);
  const [activeShift, setActiveShiftRaw] = useState<Shift>("Night");
  const [refreshCount, setRefreshCount] = useState(0);

  const triggerRefresh = useCallback(() => setRefreshCount((n) => n + 1), []);

  const getSheetKey = useCallback((d: string, s: Shift) => `${d}_${s}`, []);

  const getSheet = useCallback(
    (d: string, s: Shift): SheetRecord => {
      const db = getDB();
      const key = getSheetKey(d, s);
      if (db.sheets[key]) return db.sheets[key];
      // New blank with carry-over pulled
      const blank = makeBlankSheet(db.settings, d, s);
      const carry = pullPreviousShift(d, s, "shift");
      blank.outPrevCC    = carry.prevCC;
      blank.outTotalE    = carry.prevCredit;
      blank.outTotalF    = carry.prevDep;
      blank.outTotalCash = carry.prevCash;
      if (carry.miscRows.length > 0) {
        // Merge carried misc rows into the default 5 slots or append extras
        blank.miscRows = carry.miscRows.map((m) => ({
          label: m.label,
          val: m.val,
          status: m.status,
        }));
      }
      // Carry previous bill num
      const prevStep = timelineStep(d, s, -1);
      const prevSheet = db.sheets[prevStep.key];
      if (prevSheet) {
        blank.outCust = prevSheet.inLastBillNum;
      }
      return blank;
    },
    [getSheetKey]
  );

  const saveSheet = useCallback(
    (d: string, s: Shift, data: SheetRecord) => {
      const key = getSheetKey(d, s);
      updateDB((db) => {
        db.sheets[key] = data;
      });
      triggerRefresh();
    },
    [getSheetKey, triggerRefresh]
  );

  const updateSettings = useCallback((fn: (s: Settings) => void) => {
    updateDB((db) => fn(db.settings));
    triggerRefresh();
  }, [triggerRefresh]);

  const setDate = useCallback((d: string) => {
    setDateRaw(d);
    setActiveShiftRaw("Night");
  }, []);

  const setActiveShift = useCallback((s: Shift) => {
    setActiveShiftRaw(s);
  }, []);

  return {
    date,
    setDate,
    activeShift,
    setActiveShift,
    sheets: getDB().sheets,
    settings: getDB().settings,
    saveSheet,
    getSheet,
    getSheetKey,
    updateSettings,
    triggerRefresh,
    refreshCount,
  };
}
