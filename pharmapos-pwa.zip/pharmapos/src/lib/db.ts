/* ─── PharmaPos persistent store (localStorage) ─── */

export const SHIFTS = ["Night", "Morning", "Evening"] as const;
export type Shift = (typeof SHIFTS)[number];

export const SHIFT_SR: Record<Shift, number> = { Morning: 1, Evening: 2, Night: 3 };
export function srLabel(shift: Shift) {
  return `Closing ${SHIFT_SR[shift]} — ${shift}`;
}

export const DENOMS = [
  { label: "Rs. 5,000 notes", mult: 5000 },
  { label: "Rs. 1,000 notes", mult: 1000 },
  { label: "Rs. 500 notes",   mult: 500  },
  { label: "Rs. 100 notes",   mult: 100  },
  { label: "Rs. 50 notes",    mult: 50   },
  { label: "Rs. 20 notes",    mult: 20   },
  { label: "Rs. 10 notes",    mult: 10   },
  { label: "Coins / loose",   mult: 1    },
];

export const CASH_RESERVE = 45000;

/* ── Types ── */
export interface HsRow    { lbl: string; val: number }
export interface StripRow { lbl: string; price: number; qty: number }
export interface MiscRow  { label: string; val: number; status: "Active" | "Confirmed" | "Cleared" }
export interface CreditRow { lbl: string; val: number }
export interface TierCredit { tIdx: string; name: string; val: number }
export interface DepositRow { lbl: string; val: number }

export interface SheetRecord {
  profileMode: "shift" | "final";
  draft?: boolean;
  overrides: Record<string, number>;
  inSysCash: number;
  inLastBillAmt: number;
  inLastBillNum: number;
  inCompSale: number;
  inAlfalah: number;
  inKeenu: number;
  inBook1: number;
  inBook2: number;
  posRet1: number;
  posRet2: number;
  posRet3: number;
  posRetSys: number;
  outNetSale: number;
  outCurrCC: number;
  outPrevCC: number;
  outTotalE: number;
  creditAdj: number;
  extraCash: number;
  outTotalF: number;
  outTotalCash: number;
  outShiftSale: number;
  outCust: number;
  finalSysReturns: number;
  finalNetSale: number;
  finalPrevSale: number;
  hsRows: HsRow[];
  strips: StripRow[];          // built-in inventory items (qty only, price from settings)
  auxStrips: StripRow[];       // custom extra items
  tillValues: number[];
  vaultValues: number[];
  namedCredits: CreditRow[];
  tierCredits: TierCredit[];
  auxCredits: CreditRow[];
  deposits: DepositRow[];
  miscRows: MiscRow[];
}

export interface NamedCredit { label: string }
export interface SubTier     { type: string; names: string[] }
export interface StripSetting { name: string; price: number }

export interface Settings {
  finalEveryN: number;
  namedCredits: NamedCredit[];
  subTiers: SubTier[];
  strips: StripSetting[];
  branchName?: string;
}

export interface DB {
  settings: Settings;
  sheets: Record<string, SheetRecord>;
}

const STORAGE_KEY = "pharmpos_v3";

const defaultSettings: Settings = {
  finalEveryN: 3,
  namedCredits: [
    { label: "Corporate Account" },
    { label: "Wholesale Ledger" },
    { label: "Third Party Tab" },
  ],
  subTiers: [
    { type: "Staff Credit",   names: ["Dr. Salman", "Asif Malik", "Kashif Shah"] },
    { label: "Staff Credit", type: "Delivery Staff", names: ["Raza Hazrat", "Noman Ali", "Saeed Khan"] } as unknown as SubTier,
    { label: "Staff Credit", type: "Branch Tabs",    names: ["Johar Town", "DHA Branch", "Bahria Pool"] } as unknown as SubTier,
  ],
  strips: [
    { name: "Water 1.5L",      price: 17 },
    { name: "Water 500ml",     price: 28 },
    { name: "Water 330ml",     price: 0  },
    { name: "Regular Strips",  price: 10 },
    { name: "Pura Water 1L",   price: 16 },
    { name: "Pura Water 0.5L", price: 28 },
    { name: "Juice Pack 60x",  price: 0  },
    { name: "Juice Pack 80x",  price: 60 },
    { name: "Juice Pack 140x", price: 5  },
    { name: "Juice Pack 150x", price: 4  },
    { name: "Juice Pack 250x", price: 6  },
  ],
};

function loadDB(): DB {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DB;
      // ensure settings have all keys
      if (!parsed.settings.finalEveryN) parsed.settings.finalEveryN = 3;
      if (!parsed.settings.namedCredits) parsed.settings.namedCredits = defaultSettings.namedCredits;
      if (!parsed.settings.subTiers) parsed.settings.subTiers = defaultSettings.subTiers;
      if (!parsed.settings.strips) parsed.settings.strips = defaultSettings.strips;
      return parsed;
    }
  } catch { /* ignore */ }
  return { settings: { ...defaultSettings }, sheets: {} };
}

let _db: DB = loadDB();

export function getDB(): DB { return _db; }

export function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(_db));
}

export function updateDB(fn: (db: DB) => void) {
  fn(_db);
  persist();
}

export function exportJSON() {
  const blob = new Blob([JSON.stringify(_db, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `pharmapos_backup_${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function importJSON(json: string): string | null {
  try {
    const incoming = JSON.parse(json) as DB;
    if (!incoming.sheets || !incoming.settings) return "Invalid backup file";
    _db = incoming;
    persist();
    return null;
  } catch (e) {
    return (e as Error).message;
  }
}

/* ── Timeline helpers ── */
export function timelineStep(ds: string, shift: Shift, n: number): { key: string; date: string; shift: Shift } {
  const d = new Date(ds + "T12:00:00"); // noon to avoid DST edge
  let idx = SHIFTS.indexOf(shift) + n;
  if (idx >= SHIFTS.length) {
    d.setDate(d.getDate() + Math.floor(idx / SHIFTS.length));
    idx = idx % SHIFTS.length;
  } else if (idx < 0) {
    const steps = Math.ceil(Math.abs(idx) / SHIFTS.length);
    d.setDate(d.getDate() - steps);
    idx = ((SHIFTS.length + (idx % SHIFTS.length)) % SHIFTS.length);
  }
  const outDs = d.toISOString().split("T")[0];
  return { key: `${outDs}_${SHIFTS[idx]}`, date: outDs, shift: SHIFTS[idx] };
}

export function findLastFinal(ds: string, shift: Shift): { key: string; rec: SheetRecord } | null {
  let cur = { date: ds, shift };
  for (let i = 0; i < 400; i++) {
    const next = timelineStep(cur.date, cur.shift as Shift, -1);
    cur = { date: next.date, shift: next.shift };
    const rec = _db.sheets[next.key];
    if (rec && rec.profileMode === "final") return { key: next.key, rec };
    if (!rec && i > 200) break;
  }
  return null;
}

export interface AggResult {
  lastFinal: { key: string; rec: SheetRecord } | null;
  totalCustomers: number;
  totalShiftSale: number;
  totalManualReturns: number;
  totalExtraCash: number;
  shiftCount: number;
  labels: string[];
}

export function aggregateSinceLastFinal(ds: string, shift: Shift): AggResult {
  const lastFinal = findLastFinal(ds, shift);
  let cur = { date: ds, shift };
  let totalCustomers = 0, totalShiftSale = 0, totalManualReturns = 0, totalExtraCash = 0, shiftCount = 0;
  const labels: string[] = [];
  for (let i = 0; i < 400; i++) {
    const next = timelineStep(cur.date, cur.shift as Shift, -1);
    cur = { date: next.date, shift: next.shift };
    if (lastFinal && next.key === lastFinal.key) break;
    const rec = _db.sheets[next.key];
    if (!rec) { if (!lastFinal) break; else continue; }
    if (rec.profileMode === "final") break;
    totalCustomers    += rec.outCust || 0;
    totalShiftSale    += rec.outShiftSale || 0;
    totalManualReturns += (rec.posRet1 || 0) + (rec.posRet2 || 0) + (rec.posRet3 || 0) + (rec.posRetSys || 0);
    totalExtraCash    += rec.extraCash || 0;
    shiftCount++;
    labels.unshift(srLabel(next.shift as Shift).replace("Closing", "C") + " " + next.date);
  }
  return { lastFinal, totalCustomers, totalShiftSale, totalManualReturns, totalExtraCash, shiftCount, labels };
}

/* ── Pull carry-over from previous shift ── */
export interface CarryData {
  prevCC: number;
  prevCredit: number;
  prevDep: number;
  prevCash: number;
  miscRows: MiscRow[];
}

export function pullPreviousShift(ds: string, shift: Shift, mode: "shift" | "final"): CarryData {
  const prev = timelineStep(ds, shift, -1);
  const hs = _db.sheets[prev.key];
  const dayChanged = ds !== prev.date;

  if (!hs) return { prevCC: 0, prevCredit: 0, prevDep: 0, prevCash: 0, miscRows: [] };

  const ccB = hs.outCurrCC || 0;
  const ccP = hs.outPrevCC || 0;
  const prevCC = dayChanged ? (ccB + ccP) : ccB;

  // Misc carry-over: Active rows carry forward; Confirmed/Cleared → zeroed out with [NIL]
  const miscRows: MiscRow[] = [];
  if (mode !== "final" && hs.miscRows) {
    hs.miscRows.forEach((m) => {
      if (m.status === "Confirmed" || m.status === "Cleared") {
        if (m.label) miscRows.push({ label: m.label + " [NIL]", val: 0, status: "Cleared" });
      } else if (m.label) {
        miscRows.push({ label: m.label, val: m.val, status: m.status || "Active" });
      }
    });
  }

  return {
    prevCC,
    prevCredit: hs.outTotalE || 0,
    prevDep:    hs.outTotalF || 0,
    prevCash:   hs.outTotalCash || 0,
    miscRows,
  };
}

/* ── Format ── */
export function fmtRs(n: number) {
  return "Rs. " + Math.round(n).toLocaleString("en-PK");
}
