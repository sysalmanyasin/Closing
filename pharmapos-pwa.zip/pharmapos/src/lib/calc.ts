/* ─── Calculation engine for PharmaPos ─── */

import { DENOMS, SheetRecord, Settings, CASH_RESERVE } from "./db";

/* ── Denomination totals ── */
export function tillTotal(vals: number[]): number {
  return vals.reduce((s, v, i) => s + (v || 0) * DENOMS[i].mult, 0);
}

/* ── HS rows total ── */
export function hsTotal(rows: { val: number }[]): number {
  return rows.reduce((s, r) => s + (r.val || 0), 0);
}

/* ── Strips total ── */
export function stripsTotal(rows: { price: number; qty: number }[]): number {
  return rows.reduce((s, r) => s + (r.price || 0) * (r.qty || 0), 0);
}

/* ── Misc total (active only) ── */
export function miscTotal(rows: { val: number; status: string }[]): number {
  return rows.filter((r) => r.status === "Active").reduce((s, r) => s + (r.val || 0), 0);
}

/* ── Credit total ── */
export function creditTotal(
  named: { val: number }[],
  tier: { val: number }[],
  aux: { val: number }[]
): number {
  const all = [...named, ...tier, ...aux];
  return all.reduce((s, r) => s + (r.val || 0), 0);
}

/* ── Deposit total ── */
export function depositTotal(rows: { val: number }[]): number {
  return rows.reduce((s, r) => s + (r.val || 0), 0);
}

/* ──────────────────────────────────────────────
   GRAND TOTAL CALCULATION
   ────────────────────────────────────────────── */
export function calcGrandTotal(s: SheetRecord, settings: Settings): {
  A: number; B: number; C: number;
  D: number; E: number; F: number;
  G: number; H: number;
  grandTotal: number;
  netLiquid: number;
} {
  const A = hsTotal(s.hsRows ?? []);
  const B = stripsTotal([...(s.strips ?? []), ...(s.auxStrips ?? [])]);
  const C = miscTotal(s.miscRows ?? []);
  const D = (s.outPrevCC ?? 0) + (s.outCurrCC ?? 0);
  const E = tillTotal(s.tillValues ?? Array(8).fill(0));
  const F = tillTotal(s.vaultValues ?? Array(8).fill(0));
  const G = creditTotal(s.namedCredits ?? [], s.tierCredits ?? [], s.auxCredits ?? []);
  const H = depositTotal(s.deposits ?? []);

  const grandTotal = A + B + C + D + E + F + G + H;
  const netLiquid  = grandTotal - CASH_RESERVE;

  return { A, B, C, D, E, F, G, H, grandTotal, netLiquid };
}

/* ──────────────────────────────────────────────
   APPLY OVERRIDES — check if there's a manual override
   ────────────────────────────────────────────── */
export function applyOverride(s: SheetRecord, field: string, computed: number): number {
  if (s.overrides && s.overrides[field] !== undefined) return s.overrides[field];
  return computed;
}

/* ──────────────────────────────────────────────
   FULL SHEET DERIVATIONS
   ────────────────────────────────────────────── */
export interface Derived {
  /* Net Sale */
  totalReturns: number;
  custDelta: number;
  netSale: number;         // inSysCash + book1 + book2 + custDelta - returns
  shiftSale: number;       // override-able

  /* CC */
  currCC: number;          // inCompSale + inAlfalah + inKeenu
  prevCC: number;          // from carry

  /* Grand Total components */
  A: number; B: number; C: number;
  D: number; E: number; F: number;
  G: number; H: number;
  grandTotal: number;
  netLiquid: number;

  /* Extra cash */
  extraCash: number;       // netLiquid - outNetSale (after adj) - creditAdj - deposits - prevCash
}

export function deriveAll(s: SheetRecord, settings: Settings): Derived {
  const totalReturns = (s.posRet1 || 0) + (s.posRet2 || 0) + (s.posRet3 || 0) + (s.posRetSys || 0);

  // Customer delta = difference in bill numbers = customers
  const custDelta = Math.max(0, (s.inLastBillNum || 0) - (s.outCust || 0 /* prevBillNum */));

  // For shift mode: netSale = sysCash + book1 + book2 + custDelta - returns
  const rawNetSale = (s.inSysCash || 0) + (s.inBook1 || 0) + (s.inBook2 || 0) + custDelta - totalReturns;
  const netSale    = applyOverride(s, "netSale", rawNetSale);
  const shiftSale  = applyOverride(s, "shiftSale", (s.inSysCash || 0));

  const currCC = (s.inCompSale || 0) + (s.inAlfalah || 0) + (s.inKeenu || 0);
  const prevCC = s.outPrevCC || 0;

  const gt = calcGrandTotal(s, settings);

  // extra cash = netLiquid - (netSale - creditAdj - deposits) - prevCash
  const netAfterAdj = netSale - (s.creditAdj || 0) - depositTotal(s.deposits ?? []);
  const extraCash   = gt.netLiquid - netAfterAdj - (s.outCurrCC || 0) - (s.outPrevCC || 0) - (s.outTotalCash || 0);

  return {
    totalReturns,
    custDelta,
    netSale,
    shiftSale,
    currCC,
    prevCC,
    ...gt,
    extraCash,
  };
}
