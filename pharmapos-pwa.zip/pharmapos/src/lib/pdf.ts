/* ─── PDF / WhatsApp Share ─── */
import type { SheetRecord } from "./db";
import { fmtRs, SHIFTS, Shift, srLabel } from "./db";
import { calcGrandTotal, hsTotal, stripsTotal, miscTotal, creditTotal, depositTotal, tillTotal } from "./calc";
import type { Settings } from "./db";

export async function exportPDF(
  date: string,
  shift: Shift,
  record: SheetRecord,
  settings: Settings,
  branchName: string
) {
  // Dynamic import to avoid loading jsPDF on startup
  const [{ default: jsPDF }, { default: html2canvas }] = await Promise.all([
    import("jspdf"),
    import("html2canvas"),
  ]);

  const el = document.getElementById("print-area");
  if (!el) { alert("Print area not found"); return; }

  const canvas = await html2canvas(el, {
    scale: 2,
    useCORS: true,
    backgroundColor: "#ffffff",
  });

  const imgData = canvas.toDataURL("image/png");
  const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  const ratio = canvas.height / canvas.width;
  const imgWidth = pageWidth;
  const imgHeight = pageWidth * ratio;

  let y = 0;
  if (imgHeight <= pageHeight) {
    pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
  } else {
    // Multi-page
    let remaining = imgHeight;
    while (remaining > 0) {
      pdf.addImage(imgData, "PNG", 0, -y, imgWidth, imgHeight);
      remaining -= pageHeight;
      if (remaining > 0) { pdf.addPage(); y += pageHeight; }
    }
  }

  const filename = `Shift_${date}_${shift}.pdf`;
  pdf.save(filename);
}

export async function shareWhatsApp(
  date: string,
  shift: Shift,
  record: SheetRecord,
  settings: Settings
) {
  const { A, B, C, D, E, F, G, H, grandTotal, netLiquid } = calcGrandTotal(record, settings);
  const lines = [
    `*Fazal Din's Pharma Plus*`,
    `*${srLabel(shift)} — ${date}*`,
    ``,
    `*Sales Summary*`,
    `System Cash:  ${fmtRs(record.inSysCash)}`,
    `Book 1:       ${fmtRs(record.inBook1)}`,
    `Book 2:       ${fmtRs(record.inBook2)}`,
    `Net Sale:     ${fmtRs(record.outNetSale)}`,
    `Shift Sale:   ${fmtRs(record.outShiftSale)}`,
    ``,
    `*Closing*`,
    `HS+Strips:    ${fmtRs(A + B)}`,
    `Misc:         ${fmtRs(C)}`,
    `CC (Curr+Prev): ${fmtRs(D)}`,
    `Till:         ${fmtRs(E)}`,
    `Vault:        ${fmtRs(F)}`,
    `Credit:       ${fmtRs(G)}`,
    `Deposits:     ${fmtRs(H)}`,
    `*Grand Total: ${fmtRs(grandTotal)}*`,
    `Reserve:      Rs. 45,000`,
    `*Net Liquid:  ${fmtRs(netLiquid)}*`,
  ].join("\n");

  const url = `https://wa.me/?text=${encodeURIComponent(lines)}`;
  window.open(url, "_blank");
}
